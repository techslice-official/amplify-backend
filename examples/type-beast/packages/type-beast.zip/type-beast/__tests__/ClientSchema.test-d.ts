import { Equal, Expect } from '../src/util';

import * as a from '../index';

describe('placeholder', () => {
  it('placeholder', () => {
    expect(true);
  });
});
